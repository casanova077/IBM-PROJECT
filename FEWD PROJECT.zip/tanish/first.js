// script.js

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contactForm");
  const cartSidebar = document.getElementById("cartSidebar");
  const cartItems = document.getElementById("cartItems");
  const placeOrderBtn = document.getElementById("placeOrderBtn");
  const orderButtons = document.querySelectorAll(".order-btn");
  const burgerMenu = document.querySelector(".burger");
  const navMenu = document.querySelector("nav ul");
  const orderStatus = document.getElementById("orderStatus");
  const quantityInputs = document.querySelectorAll(".qty");

  // Email form validation
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const emailInput = this.querySelector("input[type='email']");
    const email = emailInput.value.trim();

    if (validateEmail(email)) {
      alert(`Thanks for signing up, ${email}! We'll be in touch.`);
      emailInput.value = "";
    } else {
      alert("Please enter a valid email address.");
    }
  });

  function validateEmail(email) {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
  }

  // Burger menu toggle
  burgerMenu.addEventListener("click", () => {
    navMenu.classList.toggle("active");
    cartSidebar.classList.toggle("active");
  });

  // Add item to cart when clicking "Order"
  orderButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const card = btn.closest(".card");
      const name = card.querySelector("h3").textContent;
      const quantity = card.querySelector(".qty").value;
      const price = card.querySelector(".price").textContent;

      const item = document.createElement("li");
      item.textContent = `${name} - ${quantity} pcs - ${price}`;
      cartItems.appendChild(item);

      cartSidebar.classList.add("active");
    });
  });

  // Place order
  placeOrderBtn.addEventListener("click", () => {
    if (cartItems.children.length === 0) {
      alert("Your cart is empty.");
      return;
    }

    alert("Your order has been placed successfully!");
    cartItems.innerHTML = "";
    cartSidebar.classList.remove("active");
    if (orderStatus) orderStatus.textContent = "Order placed successfully!";
  });

  // Quantity buttons functionality
  document.querySelectorAll(".quantity-control").forEach(control => {
    const input = control.querySelector(".qty");
    control.querySelector(".decrease").addEventListener("click", () => {
      let val = parseInt(input.value);
      if (val > 1) input.value = val - 1;
    });
    control.querySelector(".increase").addEventListener("click", () => {
      let val = parseInt(input.value);
      input.value = val + 1;
    });
  });
});



placeOrderBtn.addEventListener("click", () => {
  if (cartItems.innerHTML.trim() === "") {
    alert("Your cart is empty. Please add items before placing an order.");
    return;
  }

  alert("Thank you for your order! We'll process it shortly.");
  cartItems.innerHTML = ""; // clear cart
});
